package com.ll.pojo;

import lombok.Data;

@Data
public class Teacher {
	private String teacherId;
	private String tname;
	private String password;
	private int tage;
	private String tsex;
	private String tdept;
	private String tel;
	private String QQ;
	private String professional;
}
