package com.ll.pojo;

import lombok.Data;

@Data
public class Title {
	private int titleId;
	private String type;
	private String name;
	private String teacherId;
	private String src;

}
