package com.ll.pojo;

import java.util.List;
import lombok.Data;

@Data
public class Vo {
	// code msg count data
	int code;
	String msg;
	int count;
	List<Object> data;

}
