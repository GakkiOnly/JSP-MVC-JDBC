package com.ll.dao;

import java.sql.SQLException;

import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.utils.DBUtil;
import com.mysql.jdbc.PreparedStatement;

public class AdminDaoImpl implements AdminDao {

	@Override
	public int AddStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		int rs;
		int rs2;
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_student(name,password,studentId) values(?,?,?)";
		String sql2="insert into studentinfo(name,studentId) values(?,?)";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		PreparedStatement ps2=(PreparedStatement) dbUtil.getPreparedStatement(sql2);
		ps.setString(1, student.getName());
		ps.setString(2,student.getPassword());
		ps.setString(3, student.getStudentId());
		
		ps2.setString(1, student.getName());
		ps2.setString(2, student.getStudentId());
		rs=ps.executeUpdate();
		rs2=ps2.executeUpdate();
		if(rs==1&&rs2==1) {
			return 1;
	}else {
		return 0;
	}
	}
	

	@Override
	public int AddTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return 0;
	}

}
