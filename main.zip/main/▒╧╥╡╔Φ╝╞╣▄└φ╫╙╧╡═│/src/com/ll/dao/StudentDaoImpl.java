package com.ll.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;
import com.ll.pojo.Student;
import com.ll.utils.DBUtil;
public class StudentDaoImpl implements StudentDao {

	@Override
	public int ifhasTitle(String studentId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		//���������Ҳ���titleId�����⣬ԭ���������ݿ��l��i��������һ���ģ�������д���ݿ�¼���ʱ������д����
		String sql = "select titleId from studentinfo where studentId=?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1,studentId);
		ResultSet rs =ps.executeQuery();
		while(rs.next()) {
			
			return rs.getInt("titleId");
		}
		return 0;
	}

	@Override
	public int chooseTitle(String studentId, String teacherId, int titleId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo  set titleId=?,teacherId=? where studentId=?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setInt(1, titleId);
		ps.setString(2, teacherId);
		ps.setString(3, studentId);
		int rs1 =ps.executeUpdate();
		if(rs1==1) {
			
			return 1;
		}else {
			return 0;
			}
	}

	@Override
	public int delTitle(String studentId, String teacherId, int titleId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo  set titleId=0,teacherId='��' where studentId=?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, studentId);
		int rs1 = ps.executeUpdate();
		if (rs1==1) {
		return 1;
	}
		else {
		return 0;
		}
	}

	@Override
	public String getTname(int titleId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "select name from  titleinfo where titleId=?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setInt(1, titleId);
		ResultSet rs1 = ps.executeQuery();
		if (rs1.next()) {
		return rs1.getString("name");
	}
		else {
		return null;
	}
	}

	@Override
	public int submitMyProject(String studentId, String src) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo  set src=? where studentId=?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, src);	
		ps.setString(2, studentId);		
		int rs1 = ps.executeUpdate();
		if (rs1==1) {
		return 1;
	}
		else {
		return 0;
	}
	}

}
