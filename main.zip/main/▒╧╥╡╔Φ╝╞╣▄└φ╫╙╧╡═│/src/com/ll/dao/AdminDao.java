package com.ll.dao;

import java.sql.SQLException;

import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public interface AdminDao {
	public int AddStudent(Student student)throws SQLException;
	public int AddTeacher(Teacher teacher)throws SQLException;
}
