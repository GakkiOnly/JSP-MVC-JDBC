package com.ll.dao;

import java.sql.SQLException;
import java.util.List;

import com.ll.pojo.Admin;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public interface userDao {
	 public  Admin selectALlAdmin(String name,String password) throws SQLException;
	 public  Student selectALlStudent(String name,String password)throws SQLException;
	 public  Teacher selectALlTeacher(String name,String password)throws SQLException;
	 public  List<Object> selectTeacherList()throws SQLException;
	 public  List<Object> selectTeacherList(String page,String limit)throws SQLException;
	 public  List<Object> selectTitleList(String page,String limit)throws SQLException;
	 public  List<Object> selectTitleList2(String name)throws SQLException;
	 public int countTeacher()throws SQLException;
	 public  List<Object> selectStudentList()throws SQLException;
	 public  List<Object> selectStudentList(String page,String limit)throws SQLException;
	 public int countStudent()throws SQLException;
	 public int addStudent(Student student)throws SQLException;
	 public int addTeacher(Teacher teacher)throws SQLException;
	}

