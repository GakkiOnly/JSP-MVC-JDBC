package com.ll.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ll.pojo.Admin;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.pojo.Title;
import com.ll.utils.DBUtil;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.sun.org.apache.regexp.internal.recompile;

public class userDaoImpl implements userDao {

	@Override
	public Admin selectALlAdmin(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from s_admin where name=? and password=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		Admin admin=new Admin();
		while(rs.next()) {
			admin.setName(rs.getString("name"));
			admin.setPassword(rs.getString("password"));
			return admin;
			
		}
		return null;
	}

	@Override
	public Student selectALlStudent(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql = "\r\n"
				+"select * from s_student left join studentinfo on s_student.studentId=studentinfo.studentId where s_student.name=? and password=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		Student student=new Student();
		while(rs.next()) {
			student.setStudentId(rs.getString("studentId"));
			student.setName(rs.getString("name"));
			student.setPassword(rs.getString("password"));
			student.setTitleId(rs.getInt("titleId"));
			student.setSrc(rs.getString("src"));
			student.setGrade(rs.getInt("grade"));
			student.setAge(rs.getInt("age"));
			student.setSex(rs.getString("sex"));
			student.setTeacherId(rs.getString("teacherId"));
			student.setClazz(rs.getString("clazz"));
			return student;
			
		}
		return null;
	}

	@Override
	public Teacher selectALlTeacher(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from s_teacher where name=? and password=?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, name);
		ps.setString(2, password);
		ResultSet rs=ps.executeQuery();
		Teacher teacher=new Teacher();
		while(rs.next()) {
			teacher.setTeacherId(rs.getString("teacherId"));
			teacher.setTname(rs.getString("name"));
			teacher.setPassword(rs.getString("password"));
			return teacher;
			
		}
		return null;
	}

	@Override
	public List<Object> selectTeacherList() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from teacherinfo";
		Statement st=(Statement) dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Teacher teacher=new Teacher();
			teacher.setTeacherId(rs.getString("TeacherId"));
			teacher.setTname(rs.getString("tname"));
			teacher.setTsex(rs.getString("tsex"));
			teacher.setTage(rs.getInt("tage"));
			teacher.setTdept(rs.getString("tdept"));
			teacher.setTel(rs.getString("tel"));
			teacher.setQQ(rs.getString("qq"));
			teacher.setProfessional(rs.getString("professional"));
			list.add(teacher);
		}
		
		return list;
	}

	@Override
	public List<Object> selectTeacherList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from teacherinfo limit ?,?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		int page1=Integer.parseInt(page);
		int limit1=Integer.parseInt(limit);
		ps.setInt(1, (page1-1)*limit1);
		ps.setInt(2, limit1);
		ResultSet rs=ps.executeQuery();
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Teacher teacher=new Teacher();
			teacher.setTeacherId(rs.getString("TeacherId"));
			teacher.setTname(rs.getString("tname"));
			teacher.setTsex(rs.getString("tsex"));
			teacher.setTage(rs.getInt("tage"));
			teacher.setTdept(rs.getString("tdept"));
			teacher.setTel(rs.getString("tel"));
			teacher.setQQ(rs.getString("qq"));
			teacher.setProfessional(rs.getString("professional"));
			list.add(teacher);
		}
		
		return list;
	}

	@Override
	public int countTeacher() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select count(*) as sum from teacherinfo";
		Statement st=(Statement) dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			return rs.getInt("sum");
		}
		return 0;
	}

	@Override
	public List<Object> selectStudentList() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from studentinfo";
		Statement st=(Statement) dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Student student=new Student();
			student.setStudentId(rs.getString("studentId"));
			student.setName(rs.getString("name"));
			student.setSex(rs.getString("sex"));
			student.setAge(rs.getInt("age"));
			student.setTeacherId(rs.getString("teacherId"));
			student.setGrade(rs.getInt("grade"));
			student.setClazz(rs.getString("clazz"));
			student.setTitleId(rs.getInt("titleId"));
			list.add(student);
		}
		
		return list;
	}

	@Override
	public List<Object> selectStudentList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from studentinfo limit ?,?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		int page1=Integer.parseInt(page);
		int limit1=Integer.parseInt(limit);
		ps.setInt(1, (page1-1)*limit1);
		ps.setInt(2, limit1);
		ResultSet rs=ps.executeQuery();
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Student student=new Student();
			student.setStudentId(rs.getString("studentId"));
			student.setName(rs.getString("name"));
			student.setSex(rs.getString("sex"));
			student.setAge(rs.getInt("age"));
			student.setTeacherId(rs.getString("teacherId"));
			student.setGrade(rs.getInt("grade"));
			student.setClazz(rs.getString("clazz"));
			student.setTitleId(rs.getInt("titleId"));
			list.add(student);
		}
		
		return list;
	}

	@Override
	public int countStudent() throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select count(*) as sum from studentinfo";
		Statement st=(Statement) dbUtil.getStatement();
		ResultSet rs=st.executeQuery(sql);
		while(rs.next()) {
			return rs.getInt("sum");
		}
		return 0;
	}

	@Override
	public int addStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_student(name,password,studentId) values(?,?,?)";
	
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		
		ps.setString(1, student.getName());
		ps.setString(2,student.getPassword());
		ps.setString(3, student.getStudentId());
		
		int rs1=ps.executeUpdate();
		
		if(rs1==1) {
			dbUtil.commit();
			String sql2="insert into studentinfo(name,studentId) value(?,?)";
			PreparedStatement ps2=(PreparedStatement) dbUtil.getPreparedStatement(sql2);
			ps2.setString(1, student.getName());
			ps2.setString(2, student.getStudentId());
			int rs2=ps2.executeUpdate();
			if(rs2==1) {
				dbUtil.commit();
				return 1;
			}
			else {
				dbUtil.connectionRollback();
				return 0;
			}
			
		}else {
			dbUtil.connectionRollback();
			return 0;
		}
		
	}

	@Override
	public int addTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="insert into s_teacher(name,password,teacherId) values(?,?,?)";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ps.setString(1, teacher.getTname());
		ps.setString(2,teacher.getPassword());
		ps.setString(3, teacher.getTeacherId());
		int rs1=ps.executeUpdate();
		if(rs1==1) {
			dbUtil.commit();
			String sql2="insert into teacherinfo(tname,teacherId) value(?,?)";
			PreparedStatement ps2=(PreparedStatement) dbUtil.getPreparedStatement(sql2);
			ps2.setString(1, teacher.getTname());
			ps2.setString(2, teacher.getTeacherId());
			int rs2=ps2.executeUpdate();
			if(rs2==1) {
				dbUtil.commit();
				return 1;
			}else {
				dbUtil.connectionRollback();
				return 0;
			}
			
		}
		else {
			dbUtil.connectionRollback(); 
			return 0;
		}
		
	}

	@Override
	public List<Object> selectTitleList(String page, String limit) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil=new DBUtil();
		String sql="select * from titleinfo limit ?,?";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		int page1=Integer.parseInt(page);
		int limit1=Integer.parseInt(limit);
		ps.setInt(1, (page1-1)*limit1);
		ps.setInt(2, limit1);
		ResultSet rs=ps.executeQuery();
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Title title=new Title();
			title.setTitleId(rs.getInt("titleId"));
			title.setType(rs.getString("type"));
			title.setName(rs.getString("name"));
			title.setTeacherId(rs.getString("teacherId"));
			list.add(title);
		}
		
		return list;
	}

	@Override
	public List<Object> selectTitleList2(String name) throws SQLException {
		// TODO Auto-generated method stub
		
		DBUtil dbUtil=new DBUtil();
		String sql="select * from titleinfo where name like '%"+name+"%'";
		PreparedStatement ps=(PreparedStatement) dbUtil.getPreparedStatement(sql);
		ResultSet rs=ps.executeQuery();
		List<Object> list=new ArrayList<Object>();
		while(rs.next()) {
			Title title=new Title();
			title.setTitleId(rs.getInt("titleId"));
			title.setType(rs.getString("type"));
			title.setName(rs.getString("name"));
			title.setTeacherId(rs.getString("teacherId"));
			list.add(title);
		}
		
		return list;
	}


	

	
	
	
	}


