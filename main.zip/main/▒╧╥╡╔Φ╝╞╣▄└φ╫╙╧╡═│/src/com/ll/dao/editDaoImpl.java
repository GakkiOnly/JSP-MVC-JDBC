package com.ll.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.utils.DBUtil;
import com.mysql.jdbc.PreparedStatement;

public class editDaoImpl implements editDao {

	@Override
	public int EditTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update teacherinfo set tname=?,tage=?,tsex=?,tdept=?,tel=?,QQ=?,professional=? where teacherId=?";
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1,teacher.getTname());
		ps.setInt(2,teacher.getTage());
		ps.setString(3,teacher.getTsex());
		ps.setString(4,teacher.getTdept());
		ps.setString(5,teacher.getTel());
		ps.setString(6,teacher.getQQ());
		ps.setString(7,teacher.getProfessional());
		ps.setString(8,teacher.getTeacherId());
		int rs = ps.executeUpdate();
		while(rs==1) {
			return 1;
		}
		return 0;
	}

	@Override
	public int EditStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo set name=?,sex=?,age=?,teacherId=?,grade=?,clazz=?,titleId=? where StudentId=?";
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1,student.getName());
		ps.setString(2,student.getSex());
		ps.setInt(3,student.getAge());
		ps.setString(4,student.getTeacherId());
		ps.setInt(5,student.getGrade());
		ps.setString(6,student.getClazz());
		ps.setInt(7,student.getTitleId());
		ps.setString(8,student.getStudentId());
		int rs = ps.executeUpdate();
		while(rs==1) {
			return 1;
		}
		return 0;
	}

}
