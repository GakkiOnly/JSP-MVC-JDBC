package com.ll.dao;

import java.sql.SQLException;

import com.ll.controller.EditTeacher;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public interface editDao {
public int EditTeacher(Teacher teacher)throws SQLException;
public int EditStudent(Student student)throws SQLException;
}
