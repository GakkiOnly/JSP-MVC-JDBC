package com.ll.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.pojo.Title;
import com.ll.utils.DBUtil;

public class TeacherDaoImpl implements TeacherDao {

	@Override
	public int addTitle(Title title) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "insert into titleinfo(type,name,src,teacherId) values(?,?,?,?)";
		
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		
		ps.setString(1, title.getType());
		ps.setString(2, title.getName());
		ps.setString(3, title.getSrc());
		ps.setString(4, title.getTeacherId());
		
	
		int rs1 = ps.executeUpdate();
		//System.out.println(rs1);
	//	System.out.println(rs1+"    test");
		if(rs1==1) {
			
				return 1;
			}else {
				dbUtil.connectionRollback();
				return 0;
			}

		
	}

	@Override
	public List<Object> selectMyStudentList(String page, String limit, String teacherId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "select * from studentinfo where teacherId=? limit ?,?"; 
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		int page1 = Integer.parseInt(page);
		int limit1 = Integer.parseInt(limit);
		//ps.setInt(1, page1); //�ֱ��ȡ��ҳ��ҳ��page1��ÿҳ����������limit1
		ps.setString(1, teacherId);
		ps.setInt(2, (page1-1)*limit1); //����ֱ����page1����ʾ���ݣ���0��ʼҪ�ã�page1-1��*limit1��ÿҳ����������������������ʾ�쳣
		
		ps.setInt(3, limit1);
		ResultSet rs =ps.executeQuery();
		//List<Object> list = null; //�޸�Ϊ������һ�зǿ��趨�����ݽӿ������쳣:parsererror ��ʧ
		List<Object> list = new ArrayList<Object>();
		while(rs.next()) {
			Student student = new Student();
			student.setStudentId(rs.getString("studentId"));
			student.setTeacherId(rs.getString("teacherId"));
			student.setName(rs.getString("name"));
			student.setSex(rs.getString("sex"));
			student.setAge(rs.getInt("age"));
			student.setTitleId(rs.getInt("titleId"));
			student.setGrade(rs.getInt("grade"));
			student.setClazz(rs.getString("clazz"));
			student.setSrc(rs.getString("src"));
			//student.setStudentId(rs.getInt("studentId"));
			
			list.add(student);
			
		}
		return list;
	}

	@Override
	public int countMyStudent(String teacherId) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "select count(*) as sum from studentinfo where teacherId =?";
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setString(1, teacherId);
		ResultSet rs = ps.executeQuery();
		while (rs.next()) {
			return rs.getInt("sum");
		}
	
		return 0;
	}
	/*
	@Override
	public int editGrade(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo set grade=? where studentId=?";
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setInt(1,student.getGrade());
		ps.setInt(2,student.getStudentId());
		int rs = ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
	
		return 0;
	}*/

	@Override
	public int editGrade(Student student) throws SQLException {
		// TODO Auto-generated method stub
		DBUtil dbUtil = new DBUtil();
		String sql = "update studentinfo set grade=? where studentId=?";
		PreparedStatement ps = (PreparedStatement)dbUtil.getPreparedStatement(sql);
		ps.setInt(1,student.getGrade());
		ps.setString(2,student.getStudentId());
		int rs = ps.executeUpdate();
		while(rs==1) {
			
			return 1;
		}
	
		return 0;
	}


}
