package com.ll.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.service.LoginService;
import com.ll.service.LoginServletImpl;

/**
 * Servlet implementation class CheckZhuCeServlet
 */
@WebServlet("/CheckZhuCeServlet")
public class CheckZhuCeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService =new LoginServletImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckZhuCeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	doGet(request, response);
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String id=request.getParameter("id");
		String entity=request.getParameter("entity");
		Student student;
		Teacher teacher;
		if(entity.equals("ѧ��")) {
			try {
				student=loginService.selectALlStudent(name, password);
				if(student==null) {
					student=new Student();
					student.setStudentId(id);
					student.setName(name);
					student.setPassword(password);
					int s=loginService.addStudent(student);
					if(s==1) {
						response.getWriter().write("success");
					}else {
						response.getWriter().write("fail");
					}
					
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(entity.equals("��ʦ")) {
			try {
				teacher=loginService.selectALlTeacher(name, password);
				if(teacher==null) {
					teacher=new Teacher();
					teacher.setTeacherId(id);
					teacher.setTname(name);;
					teacher.setPassword(password);
					int s=loginService.addTeacher(teacher) ;
					if(s==1) {
						response.getWriter().write("success");
					}else {
						response.getWriter().write("fail");
					}
					
				}else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	}
	}
	}
	
