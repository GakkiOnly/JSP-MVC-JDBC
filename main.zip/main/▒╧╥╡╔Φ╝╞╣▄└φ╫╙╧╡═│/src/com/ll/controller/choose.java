package com.ll.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ll.dao.StudentDao;
import com.ll.dao.StudentDaoImpl;

/**
 * Servlet implementation class choose
 */
@WebServlet("/choose")
public class choose extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private StudentDao studentDao=new StudentDaoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public choose() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html;charset=utf-8");
		
		String studentId = request.getParameter("studentId");
		String teacherId = request.getParameter("teacherId");
		String title = request.getParameter("titleId");
		int titleId = Integer.parseInt(title);
		try {
			int a=studentDao.ifhasTitle(studentId);
			if (a!=0) {
				response.getWriter().write("ѡ��ʧ�ܣ������Ѿ���ѡ�⣡"+a);
				System.out.println("ѡ��ʧ�ܽ����ӡ:"+a);
			}else {
				//��δѡ�⣬��ʾѡ��ɹ�
				int b=studentDao.chooseTitle(studentId, teacherId, titleId);
				if(b==1) {
					response.getWriter().write("���ɹ�ѡ����"+titleId+"ѡ��");
					System.out.println("ѡ��ɹ������ӡ:"+b);
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
