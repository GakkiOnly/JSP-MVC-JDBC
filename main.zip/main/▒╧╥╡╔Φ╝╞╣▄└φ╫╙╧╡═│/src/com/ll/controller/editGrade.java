package com.ll.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ll.dao.TeacherDao;
import com.ll.dao.TeacherDaoImpl;
import com.ll.pojo.Student;

/**
 * Servlet implementation class editGrade
 */
@WebServlet("/editGrade")
public class editGrade extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private TeacherDao teacherDao=new TeacherDaoImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editGrade() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String studentId = request.getParameter("studentId");
		String grade = request.getParameter("grade");
		int g = Integer.parseInt(grade);
		Student student = new Student();
		student.setStudentId(studentId);
		student.setGrade(g);
		try {
			int a = teacherDao.editGrade(student);
			if(a==1) {
				response.getWriter().write("success");
			}else {
				response.getWriter().write("fail");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
