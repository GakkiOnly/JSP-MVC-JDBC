package com.ll.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSONObject;
import com.ll.dao.userDao;
import com.ll.dao.userDaoImpl;
import com.ll.pojo.Vo;

/**
 * Servlet implementation class SelectAllTeacher
 */
@WebServlet("/SelectAllTeacher")
public class SelectAllTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SelectAllTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String pageStr=request.getParameter("page");
		String limitStr=request.getParameter("limit");
		userDao userDao=new userDaoImpl();
		try {
			//List<Object> list=userDao.selectTeacherList();
			List<Object> list=userDao.selectTeacherList(pageStr,limitStr);
			response.setContentType("text/html;charset=utf-8");
			userDao.selectTeacherList();
			Vo vo=new Vo();
			vo.setCode(0);
			vo.setMsg("success");
			vo.setCount(userDao.countTeacher());
			vo.setData(list);
			response.getWriter().write(JSONObject.toJSON(vo).toString());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
