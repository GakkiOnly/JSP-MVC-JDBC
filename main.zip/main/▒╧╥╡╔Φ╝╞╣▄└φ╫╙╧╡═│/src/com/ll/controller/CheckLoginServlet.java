package com.ll.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ll.pojo.Admin;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;
import com.ll.service.LoginService;
import com.ll.service.LoginServletImpl;

/**
 * Servlet implementation class CheckLoginServlet
 */
@WebServlet("/CheckLoginServlet")
public class CheckLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private LoginService loginService=new LoginServletImpl();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String entity=request.getParameter("entity");
		if(entity.equals("����Ա")) {
			Admin admin;
			try {
				admin=loginService.selectALlAdmin(name, password);
				
				if(admin!=null) {
					HttpSession session=request.getSession();
					session.setAttribute("admin", admin);
					response.getWriter().write("success");
				}
				else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}else if(entity.equals("ѧ��")) {
			Student student;
			try {
				student=loginService.selectALlStudent(name, password);
				if(student!=null) {
					HttpSession session=request.getSession();
					session.setAttribute("student", student);
					response.getWriter().write("success");
				}
				else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}else if(entity.equals("��ʦ")) {
			Teacher teacher;
			try {
				teacher=loginService.selectALlTeacher(name, password);
				if(teacher!=null) {
					HttpSession session=request.getSession();
					session.setAttribute("teacher", teacher);
					response.getWriter().write("success");
				}
				else {
					response.getWriter().write("fail");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
