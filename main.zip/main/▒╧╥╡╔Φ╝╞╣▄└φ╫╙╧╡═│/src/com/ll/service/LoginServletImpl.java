package com.ll.service;

import java.sql.SQLException;

import com.ll.dao.userDao;
import com.ll.dao.userDaoImpl;
import com.ll.pojo.Admin;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public class LoginServletImpl implements LoginService {
private userDao userDao=new userDaoImpl();
	@Override
	public Admin selectALlAdmin(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlAdmin(name, password);
	}

	@Override
	public Student selectALlStudent(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlStudent(name, password);
	}

	@Override
	public Teacher selectALlTeacher(String name, String password) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.selectALlTeacher(name, password);
	}

	@Override
	public int addStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.addStudent(student);
	}

	@Override
	public int addTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		return userDao.addTeacher(teacher);
	}

}
