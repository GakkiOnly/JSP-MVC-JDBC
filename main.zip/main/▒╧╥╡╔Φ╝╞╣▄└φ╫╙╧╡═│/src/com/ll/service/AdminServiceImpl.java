package com.ll.service;

import java.sql.SQLException;

import com.ll.dao.AdminDao;
import com.ll.dao.AdminDaoImpl;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public class AdminServiceImpl implements AdminService {
private AdminDao adminDao=new AdminDaoImpl();
	@Override
	public int AddStudent(Student student) throws SQLException {
		// TODO Auto-generated method stub
		return adminDao.AddStudent(student);
	}

	@Override
	public int AddTeacher(Teacher teacher) throws SQLException {
		// TODO Auto-generated method stub
		return adminDao.AddTeacher(teacher);
	}

}
