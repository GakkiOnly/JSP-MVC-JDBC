package com.ll.service;

import java.sql.SQLException;

import com.ll.pojo.Admin;
import com.ll.pojo.Student;
import com.ll.pojo.Teacher;

public interface LoginService {
	 public  Admin selectALlAdmin(String name,String password) throws SQLException;
	 public  Student selectALlStudent(String name,String password)throws SQLException;
	 public  Teacher selectALlTeacher(String name,String password)throws SQLException;
	 public int addStudent(Student student)throws SQLException;
	 public int addTeacher(Teacher teacher)throws SQLException;
}
